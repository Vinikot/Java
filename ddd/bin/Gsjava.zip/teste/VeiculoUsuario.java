package teste;

public class VeiculoUsuario extends Veiculo{

}
